package Assessment_2;

public class No_Of_Elements_2 {

	public static void main(String[] args) {
		int arr[]= {1,2,3,4,5};
		int n=arr.length;
		System.out.println("Number of elements in array: "+n);
	}

}

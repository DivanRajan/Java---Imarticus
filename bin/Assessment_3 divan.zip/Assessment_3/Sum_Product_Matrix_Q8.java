package Assessment_3;
import java.util.Scanner;
public class Sum_Product_Matrix_Q8 {

	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the order of the matrix");
		int order =s.nextInt();
		int [][]a=new int[order][order];
		System.out.println("Enter all the elements : ");
		for(int i=0;i<order;i++) {
			for (int j=0;j<order;j++) {
			int a[i]=s.nextInt();
		}
	}
	}
}
package Assessment;

public class Penny_Charity_4 {

	public static void main(String[] args) {

			int n=6; 
			int m=20;
			
			if(m/n>0) {
				System.out.println(m/n);
			}
			else
				System.out.println(-1);
			
		}

	}


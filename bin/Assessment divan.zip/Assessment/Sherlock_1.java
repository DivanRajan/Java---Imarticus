package Assessment;

public class Sherlock_1 {

	public static void main(String[] args) {

		int n=6,m=2;
			if(n%m==0) {
				System.out.println(1);
			}
			else {
				System.out.println(0);
			}
		

	}

}

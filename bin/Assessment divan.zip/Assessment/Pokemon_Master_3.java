package Assessment;

public class Pokemon_Master_3 {

	public static void main(String[] args) {

			int A=4;
			int B=3;
			
				if(A>=B) 
					System.out.println(1);
				else
					System.out.println(0);	
		}

	}
